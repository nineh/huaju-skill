"""参照样板排版（reference.py / process.py mimic）的回归测试。"""
import tempfile
from pathlib import Path

from docx import Document
from docx.shared import Pt

from scripts.formatter import PRESETS, format_document
from scripts.process import main as process_main
from scripts.reference import analyze_reference, build_preset

TEXTS = [
    "关于开展年度合规检查的通知",
    "各部门：",
    "为进一步规范内部管理，现就开展年度合规检查有关事项通知如下。",
    "一、检查范围",
    "全所各业务部门及职能部门。",
    "（一）重点内容",
    "合同管理、利益冲突审查、档案管理等。",
    "1.合同管理",
    "重点检查委托合同签订及归档情况。",
    "特此通知。",
    "山西华炬律师事务所",
    "2026年11月7日",
]


def _write_plain(path, texts=TEXTS, size=11):
    doc = Document()
    for t in texts:
        run = doc.add_paragraph().add_run(t)
        run.font.size = Pt(size)
    doc.save(path)


def test_roundtrip_official_preset_is_recovered():
    """用 official 预设排出的文档做样板，读回来的格式应与 official 一致。"""
    with tempfile.TemporaryDirectory() as d:
        raw, ref = Path(d, "raw.docx"), Path(d, "ref.docx")
        _write_plain(raw)
        format_document(str(raw), str(ref), preset_name="official")
        analysis = analyze_reference(str(ref))
        official = PRESETS["official"]
        for ptype in ("title", "heading1", "heading2", "body"):
            got = analysis["styles"][ptype]
            want = official[ptype]
            assert got["font_cn"] == want["font_cn"], ptype
            assert got["size"] == want["size"], ptype
            assert got["bold"] == want["bold"], ptype
            assert got["align"] == want["align"], ptype
        assert analysis["styles"]["body"]["line"] == ["exact", 28.0] or analysis["styles"]["body"]["line"] == ("exact", 28.0)
        assert analysis["styles"]["body"]["indent"] == 32
        assert analysis["page"] == official["page"]
        assert analysis["page_number"]["style"] == "dash"
        assert analysis["page_number"]["position"] == "outside"
        assert analysis["blank_after_title"] and analysis["blank_before_signature"]


def test_mimic_applies_reference_format():
    """mimic 模式：输出文档的格式应与样板一致，而不是与内置预设一致。"""
    with tempfile.TemporaryDirectory() as d:
        raw, ref, src, out = (Path(d, n) for n in ("raw.docx", "ref.docx", "src.docx", "out.docx"))
        _write_plain(raw)
        custom = dict(PRESETS["legal"])
        custom["body"] = dict(custom["body"], font_cn="楷体", size=15, line_spacing=30)
        custom["page_number"] = False
        format_document(str(raw), str(ref), preset_name="custom", custom_settings=custom)
        _write_plain(src, size=9)
        process_main(["mimic", str(src), str(out), "--reference", str(ref), "--log-level", "ERROR"])

        out_analysis = analyze_reference(str(out))
        body = out_analysis["styles"]["body"]
        assert body["font_cn"] == "楷体"
        assert body["size"] == 15
        assert tuple(body["line"]) == ("exact", 30.0)
        assert out_analysis["page"] == custom["page"]
        assert out_analysis["page_number"] is None


def test_build_preset_inherits_body_font_for_missing_types():
    analysis = {
        "styles": {"body": {"font_cn": "宋体", "font_en": "Times New Roman", "size": 12.0, "bold": False,
                            "align": "justify", "indent": 24.0, "line": ("multiple", 1.5),
                            "space_before": 0, "space_after": 0}},
        "counts": {"body": 3},
        "page": {"top": 2.5, "bottom": 2.5, "left": 3.0, "right": 3.0},
        "page_number": None,
    }
    preset = build_preset(analysis)
    assert preset["signature"]["font_cn"] == "宋体" and preset["signature"]["size"] == 12.0
    assert preset["signature"]["align"] == "right"
    assert preset["body"]["line_spacing_multiple"] == 1.5
    assert preset["page_number"] is False


def test_legal_brief_party_lines_and_court():
    """答辩状：当事人信息不能识别成标题；"此致"后的法院顶格；文末答辩人为落款。"""
    from scripts.formatter import _build_text_context, detect_para_type
    texts = [
        "答辩状",
        "答辩人：某某科技有限公司太原分公司",
        "地  址：山西省太原市某某路1号",
        "负责人：张某，经理",
        "针对贵院受理的原告李某诉答辩人劳动争议纠纷一案，答辩人作如下答辩。",
        "一、原告的请求已超过仲裁时效",
        "根据有关法律规定，劳动争议申请仲裁的时效期间为一年。",
        "二、原告的请求缺乏事实依据",
        "原告未提交证据证明其主张。",
        "综上，请求依法驳回原告的诉讼请求。",
        "此致",
        "太原市某某区人民法院",
        "答辩人：某某科技有限公司太原分公司",
        "2026年9月8日",
    ]
    with tempfile.TemporaryDirectory() as d:
        path = Path(d, "brief.docx")
        _write_plain(path, texts)
        out = Path(d, "out.docx")
        process_main(["smart", str(path), str(out), "--preset", "legal", "--log-level", "ERROR"])
        from scripts.reference import _typed_paragraphs
        types = {p.text.strip(): t for p, t in _typed_paragraphs(Document(str(out))) if t}
        assert types["答辩状"] == "title"
        assert types["答辩人：某某科技有限公司太原分公司"] in ("body", "signature")
        assert types["地  址：山西省太原市某某路1号"] == "body"
        assert types["太原市某某区人民法院"] == "recipient"
        assert types["2026年9月8日"] == "date"
        doc = Document(str(out))
        first_party = next(p for p in doc.paragraphs if p.text.startswith("答辩人"))
        last_party = [p for p in doc.paragraphs if p.text.startswith("答辩人")][-1]
        assert first_party.alignment != 1  # 不是居中标题
        assert last_party.alignment == 2   # 文末落款右对齐
