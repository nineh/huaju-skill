"""网页版入口：在浏览器（Pyodide）里调用排版引擎。

所有函数只读写 Pyodide 内存文件系统里的路径，返回 JSON 字符串给前端。
"""
import io
import json
import logging
import os
import tempfile
from contextlib import redirect_stdout

from scripts.formatter import PRESETS, _merge_preset_settings, format_document
from scripts.punctuation import process_document as fix_punctuation
from scripts.reference import INHERIT_FROM_BODY, describe, extract_preset
from copy import deepcopy

TYPE_NAMES = {
    "title": "主标题", "recipient": "主送对象", "heading1": "一级标题", "heading2": "二级标题",
    "heading3": "三级标题", "heading4": "四级标题", "body": "正文", "signature": "落款",
    "date": "日期", "attachment": "附件说明", "closing": "结束语",
}


class _Collector(logging.Handler):
    def __init__(self):
        super().__init__()
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())


def _with_log(fn):
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    h = _Collector()
    root.addHandler(h)
    buf = io.StringIO()
    try:
        with redirect_stdout(buf):
            result = fn()
    finally:
        root.removeHandler(h)
    return result, h.lines + [l for l in buf.getvalue().splitlines() if l.strip()]


def _counts(lines):
    """从格式化日志中统计各类段落数量。"""
    counts = {}
    for line in lines:
        s = line.strip()
        if s.startswith("[") and "]" in s:
            t = s[1:s.index("]")].strip()
            if t in TYPE_NAMES:
                counts[TYPE_NAMES[t]] = counts.get(TYPE_NAMES[t], 0) + 1
    return counts


def _output_counts(path):
    """统计排版结果里各类段落的数量。"""
    from docx import Document
    from scripts.reference import _typed_paragraphs
    counts = {}
    for _, t in _typed_paragraphs(Document(path)):
        if t in TYPE_NAMES:
            counts[TYPE_NAMES[t]] = counts.get(TYPE_NAMES[t], 0) + 1
    return counts


def _overrides(opts):
    o = {}
    if opts.get("no_page_number"):
        o["page_number"] = False
    if opts.get("smart_table_align"):
        o.setdefault("table", {})["smart_align"] = True
    return o


def run(mode, in_path, out_path, opts_json="{}"):
    opts = json.loads(opts_json or "{}")
    space_mode = opts.get("space_mode", "remove_all")
    revision = bool(opts.get("revision"))

    if mode == "punctuation":
        _, log = _with_log(lambda: fix_punctuation(in_path, out_path, space_mode=space_mode))
        return json.dumps({"ok": True, "log": log[-20:]}, ensure_ascii=False)

    reference_summary = None
    if mode == "mimic":
        preset, analysis = extract_preset(opts["reference_path"], base="official")
        reference_summary = describe(analysis)
        preset_name, custom = "custom", _merge_preset_settings(preset, _overrides(opts))
    elif mode == "custom":
        preset_name, custom = "custom", build_custom(opts.get("custom_preset") or {})
        custom = _merge_preset_settings(custom, _overrides(opts))
    elif mode == "smart":
        preset_name = opts.get("preset", "official")
        if preset_name not in PRESETS:
            preset_name = "official"
        custom = _overrides(opts) or None
    else:
        raise ValueError(f"未知模式：{mode}")

    fd, tmp = tempfile.mkstemp(suffix=".docx")
    os.close(fd)
    try:
        def work():
            fix_punctuation(in_path, tmp, space_mode=space_mode)
            format_document(tmp, out_path, preset_name=preset_name, revision_mode=revision,
                            bold_serial=not opts.get("no_bold_serial"), custom_settings=custom)
        _, log = _with_log(work)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return json.dumps({"ok": True, "counts": _output_counts(out_path), "reference": reference_summary},
                      ensure_ascii=False)


def inspect_reference(path):
    """只读样板，返回识别出的格式摘要。"""
    _, analysis = extract_preset(path)
    return describe(analysis)


def analyze(path):
    """格式诊断：只检查，不修改。"""
    from docx import Document
    from scripts.analyzer import (analyze_font, analyze_numbering, analyze_paragraph_format,
                                  analyze_punctuation, print_report)
    doc = Document(path)
    results = {
        "punctuation": analyze_punctuation(doc),
        "numbering": analyze_numbering(doc),
        "paragraph": analyze_paragraph_format(doc),
        "font": analyze_font(doc),
    }
    buf = io.StringIO()
    with redirect_stdout(buf):
        print_report(results)
    return buf.getvalue()


def preset_json(name):
    """内置预设的完整参数，供网页"自定义排版"表单预填。"""
    return json.dumps(deepcopy(PRESETS.get(name, PRESETS["official"])), ensure_ascii=False)


def reference_preset(path):
    """从样板读出的完整预设，供"自定义排版"在样板基础上微调。"""
    preset, _ = extract_preset(path)
    return json.dumps(preset, ensure_ascii=False)


def build_custom(user_preset):
    """网页自定义格式 → 完整预设。主送、落款、日期、附件、结束语跟随正文的字体、字号和行距。"""
    preset = _merge_preset_settings(deepcopy(PRESETS["official"]), user_preset)
    preset["name"] = user_preset.get("name") or "自定义格式"
    body = preset["body"]
    for ptype in INHERIT_FROM_BODY:
        if ptype in preset:
            for key in ("font_cn", "font_en", "size", "line_spacing", "line_spacing_multiple"):
                if key in body:
                    preset[ptype][key] = body[key]
                else:
                    preset[ptype].pop(key, None)
    return preset
