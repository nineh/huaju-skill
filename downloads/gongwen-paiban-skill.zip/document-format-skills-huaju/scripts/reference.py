#!/usr/bin/env python3
"""参照样板文档排版：从一份排好版的 .docx 中读出格式，生成可直接使用的预设。

用法（命令行）：
    python scripts/reference.py 样板.docx                 # 打印识别出的格式
    python scripts/reference.py 样板.docx -o 样板格式.json  # 另存为预设，供 --custom-settings 使用

在 process.py 中使用：
    python scripts/process.py mimic 待排版.docx 输出.docx --reference 样板.docx

原理：用与排版引擎相同的段落识别规则（detect_para_type）给样板文档的每个段落
归类（标题、一级标题、正文、落款……），读取每一类段落的"实际生效"格式
（逐级解析直接格式 → 字符样式 → 段落样式 → 继承样式 → 文档默认值 → 主题字体），
按字数加权取最常见的值，生成与 PRESETS 结构一致的预设字典。
"""
import argparse
import json
import logging
import re
import sys
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from scripts.formatter import PRESETS, _build_text_context, _effective_alignment, detect_para_type  # noqa: E402

logger = logging.getLogger("docformat.reference")

PARA_TYPES = (
    "title", "recipient", "heading1", "heading2", "heading3", "heading4",
    "body", "signature", "date", "attachment", "closing",
)
TYPE_NAMES = {
    "title": "主标题", "recipient": "主送对象", "heading1": "一级标题", "heading2": "二级标题",
    "heading3": "三级标题", "heading4": "四级标题", "body": "正文", "signature": "落款",
    "date": "日期", "attachment": "附件说明", "closing": "结束语",
}
# 样板中未出现的类型，从正文继承字体字号（对齐、缩进沿用基础预设）
INHERIT_FROM_BODY = ("recipient", "signature", "date", "attachment", "closing")
SIZE_NAMES = {
    42: "初号", 36: "小初", 26: "一号", 24: "小一", 22: "二号", 18: "小二", 16: "三号",
    15: "小三", 14: "四号", 12: "小四", 10.5: "五号", 9: "小五",
}
ALIGN_NAMES = {"center": "居中", "left": "左对齐", "right": "右对齐", "justify": "两端对齐"}
JC_MAP = {"center": "center", "left": "left", "start": "left", "right": "right", "end": "right",
          "both": "justify", "distribute": "justify"}
TWIPS_PER_CM = 567.0


def _on(el, attr="w:val"):
    """开关型属性（w:b 等）：存在且 val 不为 0/false 时为 True。"""
    if el is None:
        return None
    val = el.get(qn(attr))
    return val is None or val not in ("0", "false", "off")


class StyleResolver:
    """解析段落和 run 的实际生效格式。"""

    def __init__(self, doc):
        self.doc = doc
        styles_el = doc.styles.element
        self.styles = {}
        self.default_para_style = None
        for s in styles_el.findall(qn("w:style")):
            sid = s.get(qn("w:styleId"))
            self.styles[sid] = s
            if s.get(qn("w:type")) == "paragraph" and s.get(qn("w:default")) in ("1", "true", "on"):
                self.default_para_style = sid
        dd = styles_el.find(qn("w:docDefaults"))
        self.default_rpr = None
        self.default_ppr = None
        if dd is not None:
            r = dd.find(qn("w:rPrDefault"))
            p = dd.find(qn("w:pPrDefault"))
            self.default_rpr = r.find(qn("w:rPr")) if r is not None else None
            self.default_ppr = p.find(qn("w:pPr")) if p is not None else None
        self.theme_fonts = self._read_theme_fonts()

    def _read_theme_fonts(self):
        fonts = {"minorEastAsia": "宋体", "majorEastAsia": "宋体",
                 "minorHAnsi": "Times New Roman", "majorHAnsi": "Times New Roman"}
        try:
            for rel in self.doc.part.rels.values():
                if rel.reltype.endswith("/theme"):
                    from lxml import etree
                    root = etree.fromstring(rel.target_part.blob)
                    ns = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
                    for kind in ("minor", "major"):
                        font = root.find(f".//a:{kind}Font", ns)
                        if font is None:
                            continue
                        latin = font.find("a:latin", ns)
                        if latin is not None and latin.get("typeface"):
                            fonts[f"{kind}HAnsi"] = latin.get("typeface")
                            fonts[f"{kind}Ascii"] = latin.get("typeface")
                        ea = font.find("a:ea", ns)
                        ea_face = ea.get("typeface") if ea is not None else ""
                        if not ea_face:
                            hans = font.find("a:font[@script='Hans']", ns)
                            ea_face = hans.get("typeface") if hans is not None else ""
                        if ea_face:
                            fonts[f"{kind}EastAsia"] = ea_face
        except Exception as exc:  # 主题解析失败不影响主流程
            logger.debug("theme parse failed: %s", exc)
        return fonts

    def _style_chain(self, sid):
        chain, seen = [], set()
        while sid and sid in self.styles and sid not in seen:
            seen.add(sid)
            st = self.styles[sid]
            chain.append(st)
            based = st.find(qn("w:basedOn"))
            sid = based.get(qn("w:val")) if based is not None else None
        return chain

    def _para_style_id(self, p):
        ppr = p.find(qn("w:pPr"))
        if ppr is not None:
            ps = ppr.find(qn("w:pStyle"))
            if ps is not None:
                return ps.get(qn("w:val"))
        return self.default_para_style

    # ---- run 属性 ----
    def _rpr_sources(self, p, r):
        """按优先级从高到低返回 rPr 元素列表。"""
        out = []
        rpr = r.find(qn("w:rPr")) if r is not None else None
        if rpr is not None:
            out.append(rpr)
            rs = rpr.find(qn("w:rStyle"))
            if rs is not None:
                for st in self._style_chain(rs.get(qn("w:val"))):
                    sr = st.find(qn("w:rPr"))
                    if sr is not None:
                        out.append(sr)
        for st in self._style_chain(self._para_style_id(p)):
            sr = st.find(qn("w:rPr"))
            if sr is not None:
                out.append(sr)
        if self.default_rpr is not None:
            out.append(self.default_rpr)
        return out

    def run_props(self, p, r):
        srcs = self._rpr_sources(p, r)
        props = {"font_cn": None, "font_en": None, "size": None, "bold": None}
        for rpr in srcs:
            rf = rpr.find(qn("w:rFonts"))
            if rf is not None:
                if props["font_cn"] is None:
                    v = rf.get(qn("w:eastAsia"))
                    t = rf.get(qn("w:eastAsiaTheme"))
                    props["font_cn"] = v or (self.theme_fonts.get(t) if t else None)
                if props["font_en"] is None:
                    v = rf.get(qn("w:ascii")) or rf.get(qn("w:hAnsi"))
                    t = rf.get(qn("w:asciiTheme")) or rf.get(qn("w:hAnsiTheme"))
                    props["font_en"] = v or (self.theme_fonts.get(t.replace("Ascii", "HAnsi")) if t else None)
            if props["size"] is None:
                sz = rpr.find(qn("w:sz"))
                if sz is not None and sz.get(qn("w:val")):
                    props["size"] = int(sz.get(qn("w:val"))) / 2
            if props["bold"] is None:
                b = rpr.find(qn("w:b"))
                if b is not None:
                    props["bold"] = _on(b)
        props["font_cn"] = props["font_cn"] or self.theme_fonts.get("minorEastAsia") or "宋体"
        props["font_en"] = props["font_en"] or self.theme_fonts.get("minorHAnsi") or "Times New Roman"
        props["size"] = props["size"] or 10.5
        props["bold"] = bool(props["bold"])
        return props

    # ---- 段落属性 ----
    def para_props(self, p, font_size):
        srcs = []
        ppr = p.find(qn("w:pPr"))
        if ppr is not None:
            srcs.append(ppr)
        for st in self._style_chain(self._para_style_id(p)):
            sp = st.find(qn("w:pPr"))
            if sp is not None:
                srcs.append(sp)
        if self.default_ppr is not None:
            srcs.append(self.default_ppr)

        align = indent = line = before = after = None
        for src in srcs:
            if align is None:
                jc = src.find(qn("w:jc"))
                if jc is not None:
                    align = JC_MAP.get(jc.get(qn("w:val")), "left")
            ind = src.find(qn("w:ind"))
            if indent is None and ind is not None:
                fl_chars = ind.get(qn("w:firstLineChars"))
                fl = ind.get(qn("w:firstLine"))
                hang = ind.get(qn("w:hanging")) or ind.get(qn("w:hangingChars"))
                if fl_chars is not None:
                    indent = round(int(fl_chars) / 100 * font_size, 1)
                elif fl is not None:
                    indent = round(int(fl) / 20, 1)
                elif hang is not None:
                    indent = 0
            sp = src.find(qn("w:spacing"))
            if sp is not None:
                if line is None and sp.get(qn("w:line")):
                    val = int(sp.get(qn("w:line")))
                    rule = sp.get(qn("w:lineRule")) or "auto"
                    line = ("multiple", round(val / 240, 2)) if rule == "auto" else ("exact", round(val / 20, 1))
                if before is None:
                    if sp.get(qn("w:beforeLines")):
                        before = round(int(sp.get(qn("w:beforeLines"))) / 100 * font_size * 1.2, 1)
                    elif sp.get(qn("w:before")):
                        before = round(int(sp.get(qn("w:before"))) / 20, 1)
                if after is None:
                    if sp.get(qn("w:afterLines")):
                        after = round(int(sp.get(qn("w:afterLines"))) / 100 * font_size * 1.2, 1)
                    elif sp.get(qn("w:after")):
                        after = round(int(sp.get(qn("w:after"))) / 20, 1)
        return {
            "align": align or "left",
            "indent": indent or 0,
            "line": line or ("multiple", 1.0),
            "space_before": before or 0,
            "space_after": after or 0,
        }

    def paragraph_format(self, para):
        """段落的实际格式：字体取字数最多的那个 run。"""
        p = para._p
        best, best_len = None, -1
        for r in p.iter(qn("w:r")):
            text = "".join(t.text or "" for t in r.iter(qn("w:t")))
            if len(text.strip()) > best_len:
                best, best_len = r, len(text.strip())
        rp = self.run_props(p, best)
        pp = self.para_props(p, rp["size"])
        return {**rp, **pp}


def _mode(values):
    """按权重取众数。values: [(value, weight)]"""
    c = Counter()
    for v, w in values:
        c[json.dumps(v, ensure_ascii=False)] += w
    return json.loads(c.most_common(1)[0][0]) if c else None


def _detect_page_number(doc, resolver):
    sec = doc.sections[0]
    settings = doc.settings.element
    even_odd = settings.find(qn("w:evenAndOddHeaders")) is not None
    found = {}
    footers = [("odd", sec.footer)]
    if even_odd:
        footers.append(("even", sec.even_page_footer))
    for kind, footer in footers:
        if footer.is_linked_to_previous and kind == "even":
            pass
        for para in footer.paragraphs:
            xml = para._p.xml
            if "PAGE" not in xml:
                continue
            text = para.text
            if "NUMPAGES" in xml:
                style = "page_total"
            elif "页" in text:
                style = "page_text"
            elif re.search(r"[—\-–]", text):
                style = "dash"
            else:
                style = "plain"
            rp = resolver.paragraph_format(para)
            found[kind] = {"style": style, "align": rp["align"], "font": rp["font_cn"], "size": rp["size"]}
            break
    if not found:
        return None
    odd = found.get("odd") or found.get("even")
    even = found.get("even")
    if even and odd and odd["align"] == "right" and even["align"] == "left":
        position = "outside"
    else:
        position = {"left": "left", "right": "right"}.get(odd["align"], "center")
    return {"style": odd["style"], "position": position, "font": odd["font"], "size": odd["size"]}


def analyze_reference(path):
    """读样板文档，返回 {type: 格式字典} 及页面、页码信息。"""
    doc = Document(path)
    resolver = StyleResolver(doc)
    samples = defaultdict(list)
    counts = Counter()
    for para, ptype in _typed_paragraphs(doc):
        if ptype not in PARA_TYPES:
            continue
        counts[ptype] += 1
        samples[ptype].append((resolver.paragraph_format(para), max(len(para.text.strip()), 1)))

    styles = {}
    for ptype, items in samples.items():
        fmt = {}
        for key in ("font_cn", "font_en", "size", "bold", "align", "indent", "line", "space_before", "space_after"):
            fmt[key] = _mode([(f[key], w) for f, w in items])
        styles[ptype] = fmt

    # 样板在标题后、落款前是否留空行
    seq = [(para.text.strip() == "", t) for para, t in _typed_paragraphs(doc)]
    blank_after_title = blank_before_signature = False
    for k, (empty, t) in enumerate(seq):
        if t == "title" and k + 1 < len(seq) and seq[k + 1][0]:
            blank_after_title = True
        if t == "signature" and k > 0 and seq[k - 1][0]:
            blank_before_signature = True

    sec = doc.sections[0]
    page = {
        "top": round(sec.top_margin.cm, 2) if sec.top_margin is not None else None,
        "bottom": round(sec.bottom_margin.cm, 2) if sec.bottom_margin is not None else None,
        "left": round(sec.left_margin.cm, 2) if sec.left_margin is not None else None,
        "right": round(sec.right_margin.cm, 2) if sec.right_margin is not None else None,
    }
    return {"styles": styles, "counts": dict(counts), "page": page,
            "page_number": _detect_page_number(doc, resolver),
            "blank_after_title": blank_after_title, "blank_before_signature": blank_before_signature}


def _typed_paragraphs(doc):
    """按排版引擎的规则给每个段落归类（空段落类型为 None）。"""
    all_texts, idx_map = _build_text_context(doc)
    total = len(doc.paragraphs)
    prev = None
    for i, para in enumerate(doc.paragraphs):
        text = para.text.strip()
        if not text:
            yield para, None
            continue
        ptype = detect_para_type(text, i, total, _effective_alignment(para), all_texts,
                                 all_texts_index=idx_map.get(i), prev_para_type=prev)
        prev = ptype
        yield para, ptype


def build_preset(analysis, base="official", name=None):
    """把分析结果转成 format_document 可用的预设。"""
    preset = deepcopy(PRESETS.get(base, PRESETS["official"]))
    preset["name"] = name or "参照样板格式"
    styles = analysis["styles"]

    def to_fmt(s, old):
        fmt = deepcopy(old)
        fmt.update({
            "font_cn": s["font_cn"], "font_en": s["font_en"], "size": s["size"], "bold": s["bold"],
            "align": s["align"], "indent": s["indent"],
            "space_before": s["space_before"], "space_after": s["space_after"],
        })
        kind, val = s["line"]
        fmt.pop("line_spacing_multiple", None)
        if kind == "exact":
            fmt["line_spacing"] = val
        else:
            fmt["line_spacing"] = None
            fmt["line_spacing_multiple"] = val
        return fmt

    for ptype in PARA_TYPES:
        if ptype in styles:
            preset[ptype] = to_fmt(styles[ptype], preset.get(ptype, {}))
    body = styles.get("body")
    if body:
        for ptype in INHERIT_FROM_BODY:
            if ptype not in styles and ptype in preset:
                inherited = dict(body, align=preset[ptype].get("align", "left"),
                                 indent=preset[ptype].get("indent", 0) and body["indent"])
                preset[ptype] = to_fmt(inherited, preset[ptype])
    # 正文以外的类型若样板没给行距，跟正文一致，避免出现 28 磅与样板不一致
    if body:
        for ptype in PARA_TYPES:
            f = preset.get(ptype)
            if isinstance(f, dict) and ptype not in styles and ptype not in INHERIT_FROM_BODY:
                kind, val = body["line"]
                f["line_spacing"] = val if kind == "exact" else None
                if kind != "exact":
                    f["line_spacing_multiple"] = val

    if all(v is not None for v in analysis["page"].values()):
        preset["page"] = analysis["page"]
    preset["blank_after_title"] = analysis.get("blank_after_title", True)
    preset["blank_before_signature"] = analysis.get("blank_before_signature", True)
    pn = analysis.get("page_number")
    if pn:
        preset.update({
            "page_number": True,
            "page_number_style": pn["style"],
            "page_number_position": pn["position"],
            "page_number_font": pn["font"],
            "page_number_size": pn["size"],
            "replace_existing_page_number": True,
        })
    else:
        preset["page_number"] = False
    return preset


def describe(analysis):
    """生成给人看的中文摘要。"""
    lines = []
    pg = analysis["page"]
    if all(v is not None for v in pg.values()):
        lines.append(f"页边距：上 {pg['top']} cm，下 {pg['bottom']} cm，左 {pg['left']} cm，右 {pg['right']} cm")
    for ptype in PARA_TYPES:
        s = analysis["styles"].get(ptype)
        if not s:
            continue
        size = s["size"]
        size_txt = f"{SIZE_NAMES[size]}（{size:g} 磅）" if size in SIZE_NAMES else f"{size:g} 磅"
        kind, val = s["line"]
        line_txt = f"固定值 {val:g} 磅" if kind == "exact" else f"{val:g} 倍行距"
        indent_txt = f"首行缩进 {s['indent'] / size:.0f} 字符" if s["indent"] else "无缩进"
        bold = "，加粗" if s["bold"] else ""
        lines.append(f"{TYPE_NAMES[ptype]}（{analysis['counts'][ptype]} 段）：{s['font_cn']} {size_txt}{bold}，"
                     f"{ALIGN_NAMES.get(s['align'], s['align'])}，{indent_txt}，{line_txt}")
    blanks = []
    if analysis.get("blank_after_title"):
        blanks.append("标题后")
    if analysis.get("blank_before_signature"):
        blanks.append("落款前")
    lines.append("空行：" + ("、".join(blanks) + "留一行" if blanks else "标题后、落款前都不留空行"))
    pn = analysis.get("page_number")
    if pn:
        style_txt = {"dash": "— 1 —", "plain": "1", "page_text": "第 1 页", "page_total": "1 / N"}[pn["style"]]
        pos_txt = {"outside": "单页居右、双页居左", "center": "居中", "left": "居左", "right": "居右"}[pn["position"]]
        lines.append(f"页码：{style_txt}，{pos_txt}")
    else:
        lines.append("页码：样板中没有页码，排版时不添加")
    return "\n".join(lines)


def extract_preset(path, base="official"):
    analysis = analyze_reference(path)
    return build_preset(analysis, base=base, name=f"参照：{Path(path).stem}"), analysis


def main(argv=None):
    parser = argparse.ArgumentParser(description="从样板 .docx 读取格式，生成排版预设")
    parser.add_argument("reference", help="样板文档 (.docx)")
    parser.add_argument("-o", "--output", help="把预设保存为 JSON，可用于 --custom-settings")
    parser.add_argument("--base", default="official", choices=tuple(PRESETS.keys()),
                        help="样板中没有出现的段落类型，沿用哪个内置预设")
    args = parser.parse_args(argv)
    preset, analysis = extract_preset(args.reference, base=args.base)
    print(describe(analysis))
    if args.output:
        Path(args.output).write_text(json.dumps({"preset": preset}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\n已保存预设：{args.output}")


if __name__ == "__main__":
    main()
