# 修改说明（韩宇）

本技能基于 [document-format-skills](https://github.com/KaguraNanaga/document-format-skills)（MIT 协议，© KaguraNanaga），原 LICENSE 保留在本目录。

修改人：韩宇（山西华炬律师事务所），2026 年 11 月。修改内容：
- 新增 `scripts/reference.py`：从样板 .docx 读取格式，生成排版预设
- `scripts/process.py` 新增 `mimic` 模式：参照样板文档排版
- `scripts/formatter.py`：支持倍数行距（`line_spacing_multiple`）；标题后、落款前空行可由预设开关（`blank_after_title`、`blank_before_signature`）
- 新增测试 `tests/test_reference.py`
