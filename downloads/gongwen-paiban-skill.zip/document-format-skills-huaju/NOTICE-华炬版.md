# 修改说明（韩宇）

本技能基于 [document-format-skills](https://github.com/KaguraNanaga/document-format-skills)（MIT 协议，© KaguraNanaga），原 LICENSE 保留在本目录。

修改人：韩宇（山西华炬律师事务所），2026 年 11 月。修改内容：
- 新增 `scripts/reference.py`：从样板 .docx 读取格式，生成排版预设
- `scripts/process.py` 新增 `mimic` 模式：参照样板文档排版
- `scripts/formatter.py`：支持倍数行距（`line_spacing_multiple`）；标题后、落款前空行可由预设开关（`blank_after_title`、`blank_before_signature`）
- 新增测试 `tests/test_reference.py`
- 2026-11-09 法律文书识别修正（根据所内使用反馈）：当事人信息行（答辩人、地址、负责人等）不再误识别为标题；"此致"后的法院名顶格；识别答辩状、起诉状等诉讼文书标题；保留"地  址"类对齐空格；法律文书预设各级标题首行缩进 2 字、正文固定 28 磅行距
